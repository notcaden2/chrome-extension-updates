(function () {
  // Get the referral code based on the current domain
  function getReferralCode() {
    const hostname = window.location.hostname;

    if (hostname === "cnfans.com") return "155562";
    if (hostname === "mulebuy.com") return "200151616";
    if (hostname === "hoobuy.com") return "utm_source=share&utm_medium=product_details&inviteCode=zXvrg2Xw";

    return "";
  }

  // Enable the "Agree" checkbox if it's disabled and auto-check it
  function enableAgreeCheckbox() {
    const intervalId = setInterval(() => {
      const agreeCheckbox = document.querySelector("input#agree.form-check-input");
      if (agreeCheckbox && agreeCheckbox.disabled) {
        agreeCheckbox.disabled = false;
        agreeCheckbox.checked = true;
      }
    }, 200);

    // Stop trying after 12 seconds
    setTimeout(() => clearInterval(intervalId), 12000);
  }

  // Update the URL's ref parameter if necessary and reload the page
  function updateRefInURL() {
    const currentURL = new URL(window.location.href);
    const hostname = currentURL.hostname;
    const referralCode = getReferralCode();

    // Check if we are on a product page and if the ref code needs to be added or updated
    const isProductPage = currentURL.pathname.includes("/product");
    const currentRef = currentURL.searchParams.get("ref");

    if (
      (hostname === "cnfans.com" || hostname === "mulebuy.com" || hostname === "hoobuy.com") &&
      isProductPage && currentRef !== referralCode
    ) {
      currentURL.searchParams.set("ref", referralCode);
      window.location.replace(currentURL.toString());
    }
  }

  // Wait for an element to appear, then execute the callback
  function waitForElement(selector, callback, timeout = 5000) {
    const startTime = Date.now();

    (function checkElement() {
      const element = document.querySelector(selector);
      if (element) {
        callback(element);
      } else if (Date.now() - startTime < timeout) {
        setTimeout(checkElement, 100);
      }
    })();
  }

  // Handle modal removal and store removal count
  function handleModalRemoval() {
    const hostname = window.location.hostname;
    const currentRef = new URL(window.location.href).searchParams.get("ref");
    const referralCode = getReferralCode();

    // Handle modals for cnfans.com and mulebuy.com
    if (hostname === "cnfans.com" || hostname === "mulebuy.com") {
      if (currentRef === referralCode) {
        const modal = document.getElementById("keywords-modal");
        if (modal) {
          modal.style.display = "none";
          modal.remove();
          updateRemovalCount();
        }
      }
    } else if (hostname === "hoobuy.com" && currentRef === referralCode) {
      waitForElement(".el-overlay", modal => {
        modal.style.display = "none";
        modal.remove();
        updateRemovalCount();
      });
    }
  }

  // Update the removal count in Chrome's local storage
  function updateRemovalCount() {
    chrome.storage.local.get(["removalCount"], data => {
      const removalCount = data.removalCount || 0;
      chrome.storage.local.set({ removalCount: removalCount + 1 }, showRemovalNotification);
    });
  }

  // Show a notification when an element is removed
  function showRemovalNotification() {
    const notification = document.createElement("div");
    notification.id = "removal-notification";
    notification.style.position = "fixed";
    notification.style.bottom = "20px";
    notification.style.right = "20px";
    notification.style.padding = "15px 25px"; // Increased padding for a modern look
    notification.style.backgroundColor = "#00a308"; // Background color
    notification.style.color = "#ffffff"; // Text color
    notification.style.fontSize = "16px"; // Font size
    notification.style.borderRadius = "10px"; // Smooth rounded edges
    notification.style.boxShadow = "0 4px 20px rgba(0, 0, 0, 0.3)"; // Shadow for depth
    notification.style.zIndex = "1000"; // Ensure it's above other elements
    notification.style.transition = "opacity 0.5s ease, transform 0.5s ease"; // Smooth transition
    notification.style.opacity = "0"; // Start as invisible
    notification.style.transform = "translateY(10px)"; // Start slightly below

    notification.textContent = "Window removed";
    document.body.appendChild(notification);

    // Trigger fade-in animation
    requestAnimationFrame(() => {
      notification.style.opacity = "1"; // Fade in
      notification.style.transform = "translateY(0)"; // Move into position
    });

    // Set a timer for fade-out after 4.2 seconds
    setTimeout(() => {
      notification.style.opacity = "0"; // Fade out
      notification.style.transform = "translateY(10px)"; // Move slightly down

      // Remove after fade out completes
      setTimeout(() => notification.remove(), 500); // Matches the transition duration
    }, 4200); // Show for 4.2 seconds
  }

  // Function to extract ID from the URL
  function extractId(url) {
    const idMatch = url.match(/id=(\d+)(?:&ref|&shop|&from)/);
    return idMatch ? idMatch[1] : null; // Return extracted ID or null if not found
  }

  // Add buttons that redirect to Finds.ly with the extracted ID
  function addRedirectButtons() {
    const currentURL = window.location.href;

    // Check if shop_id exists in the URL
    if (currentURL.includes("shop_id")) {
      return; // Exit if shop_id is found in the URL
    }

    // Create button container
    const buttonContainer = document.createElement("div");
    buttonContainer.style.position = "fixed";
    buttonContainer.style.bottom = "20px"; // Position from bottom
    buttonContainer.style.left = "20px"; // Position from left
    buttonContainer.style.display = "flex";
    buttonContainer.style.flexDirection = "column"; // Stack buttons vertically
    buttonContainer.style.gap = "10px"; // Space between buttons
    buttonContainer.style.zIndex = "1000"; // Make sure it's visible above other elements

    // Common button styles
    const buttonStyle = {
      padding: "10px 20px",
      border: "none",
      borderRadius: "5px",
      color: "#ffffff",
      cursor: "pointer",
      fontSize: "16px",
      transition: "transform 0.3s, background-color 0.3s", // Transition for hover effects
    };

    // Button for Taobao
    const isTaobaoPage = currentURL.includes("taobao");
    if (isTaobaoPage) {
      const taobaoButton = document.createElement("button");
      taobaoButton.textContent = "Check Photos (Taobao)";
      taobaoButton.style.backgroundColor = "#5c5c5c"; // Taobao branding color
      Object.assign(taobaoButton.style, buttonStyle);

      taobaoButton.addEventListener("click", () => {
        const extractedId = extractId(currentURL);
        if (extractedId) {
          const findsLyUrl = `https://finds.ly/product/TAOBAO/${extractedId}`;
          window.open(findsLyUrl, "_blank");
        } else {
          alert("ID not found in the URL.");
        }
      });

      // Add hover effect
      taobaoButton.addEventListener("mouseenter", () => {
        taobaoButton.style.backgroundColor = "#3d3d3d"; // Darken on hover
        taobaoButton.style.transform = "scale(1.05)"; // Slightly enlarge on hover
      });
      taobaoButton.addEventListener("mouseleave", () => {
        taobaoButton.style.backgroundColor = "#5c5c5c"; // Reset background color
        taobaoButton.style.transform = "scale(1)"; // Reset size
      });

      buttonContainer.appendChild(taobaoButton);
    }

    // Button for Weidian
    const isWeidianPage = currentURL.includes("weidian");
    if (isWeidianPage) {
      const weidianButton = document.createElement("button");
      weidianButton.textContent = "Check Photos (Weidian)";
      weidianButton.style.backgroundColor = "#5c5c5c"; // Weidian branding color
      Object.assign(weidianButton.style, buttonStyle);

      weidianButton.addEventListener("click", () => {
        const extractedId = extractId(currentURL);
        if (extractedId) {
          const findsLyUrl = `https://finds.ly/product/WEIDIAN/${extractedId}`;
          window.open(findsLyUrl, "_blank");
        } else {
          alert("ID not found in the URL.");
        }
      });

      // Add hover effect
      weidianButton.addEventListener("mouseenter", () => {
        weidianButton.style.backgroundColor = "#3d3d3d"; // Darken on hover
        weidianButton.style.transform = "scale(1.05)"; // Slightly enlarge on hover
      });
      weidianButton.addEventListener("mouseleave", () => {
        weidianButton.style.backgroundColor = "#5c5c5c"; // Reset background color
        weidianButton.style.transform = "scale(1)"; // Reset size
      });

      buttonContainer.appendChild(weidianButton);
    }

    // Button for Ali 1688
    const isAli1688Page = currentURL.includes("ali_1688");
    if (isAli1688Page) {
      const ali1688Button = document.createElement("button");
      ali1688Button.textContent = "Check Photos (1688)";
      ali1688Button.style.backgroundColor = "#5c5c5c"; // Ali 1688 branding color
      Object.assign(ali1688Button.style, buttonStyle);

      ali1688Button.addEventListener("click", () => {
        const extractedId = extractId(currentURL);
        if (extractedId) {
          const findsLyUrl = `https://finds.ly/product/ONE_SIX_EIGHT_EIGHT/${extractedId}`;
          window.open(findsLyUrl, "_blank");
        } else {
          alert("ID not found in the URL.");
        }
      });

      // Add hover effect
      ali1688Button.addEventListener("mouseenter", () => {
        ali1688Button.style.backgroundColor = "#3d3d3d"; // Darken on hover
        ali1688Button.style.transform = "scale(1.05)"; // Slightly enlarge on hover
      });
      ali1688Button.addEventListener("mouseleave", () => {
        ali1688Button.style.backgroundColor = "#5c5c5c"; // Reset background color
        ali1688Button.style.transform = "scale(1)"; // Reset size
      });

      buttonContainer.appendChild(ali1688Button);
    }

    // Append button container to the body
    document.body.appendChild(buttonContainer);
  }

  // Initialize the script when the DOM is ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      updateRefInURL();
      handleModalRemoval();
      enableAgreeCheckbox();
      addRedirectButtons();
    });
  } else {
    updateRefInURL();
    handleModalRemoval();
    enableAgreeCheckbox();
    addRedirectButtons();
  }
})();
